﻿using System;
using System.Collections.Generic;

namespace MarkovText
{
    class Program
    {
        static void Main(string[] args)
        {
            string file = @"D:\Users\MasterUser\Desktop\Information theory\Ipsum.txt";
            int nGram = 5;

            Console.WriteLine("Ksystof Stanislav Sokolovski Prifs 18/5 Markov Text \n");

            HelperFunctions functionService = new();

            string readFile = functionService.ReadFile(file);

            string filteredString = functionService.Filter(readFile);

            string[] words = filteredString.Split(' ');

            functionService.ExecuteMarkovText(words, nGram);
        }        
    }
}
